import os
import shutil
import argparse
import datetime
import logging
import sys
import smtplib
from backupcfg import BACKUP_JOBS, backupfilename

# Configure logging
logging.basicConfig(
    filename=backupfilename,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def create_timestamp():
    """Return current timestamp as YYYYMMDD_HHMMSS string."""
    return datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

def send_alert(job_name, error_msg):
    """Simulate sending an alert (can be extended to email, SMS, webhook)."""
    sendEmail(f"Backup job '{job_name}' error:\n{error_msg}")

# SMTP configuration for Mailjet
smtp = {
    "sender": "huntharrison60@gmail.com",              # Mailjet verified sender
    "recipient": "30025737@students.sunitafe.edu.au",    # Mailjet verified recipient
    "server": "in-v3.mailjet.com",              # Mailjet SMTP server
    "port": 587,                                # Mailjet SMTP port
    "user": "",  # Mailjet API user
    "password": ""  # Mailjet API password
}

def sendEmail(message):
    """Send an email with the error message via SMTP."""
    email_content = (
        f"To: {smtp['recipient']}\n"
        f"From: {smtp['sender']}\n"
        f"Subject: Backup Error\n\n"
        f"{message}\n"
    )
    try:
        server = smtplib.SMTP(smtp["server"], smtp["port"])
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(smtp["user"], smtp["password"])
        server.sendmail(smtp["sender"], smtp["recipient"], email_content)
        server.quit()
    except Exception as e:
        print(f"[ERROR] Failed to send email: {e}")

def backup_job(job_name, src_path, dest_path):
    """Perform backup for a given job. Handles files or directories with timestamp."""
    timestamp = create_timestamp()
    dest_with_timestamp = os.path.join(dest_path, f"{job_name}_{timestamp}")

    try:
        if not os.path.exists(src_path):
            logging.error(f"{job_name} - FAIL - Source path '{src_path}' does not exist.")
            send_alert(job_name, f"Source path '{src_path}' does not exist.")
            print(f"[WARN] Source path '{src_path}' not found for job '{job_name}'. Skipping.")
            return

        os.makedirs(dest_path, exist_ok=True)

        if os.path.isfile(src_path):
            os.makedirs(dest_with_timestamp, exist_ok=True)
            shutil.copy2(src_path, dest_with_timestamp)
        else:
            shutil.copytree(src_path, dest_with_timestamp)

        logging.info(f"{job_name} - SUCCESS")
        print(f"[INFO] Backup job '{job_name}' completed successfully → {dest_with_timestamp}")

    except Exception as e:
        logging.error(f"{job_name} - FAIL - {e}")
        send_alert(job_name, str(e))
        print(f"[ERROR] Backup job '{job_name}' failed: {e}")

def main():
    parser = argparse.ArgumentParser(description="Backup Program")
    parser.add_argument(
        "jobs",
        nargs="*",
        help="Name(s) of backup jobs to run (default: all jobs)"
    )
    args = parser.parse_args()

    if not args.jobs:
        args.jobs = list(BACKUP_JOBS.keys())
        print(f"[INFO] No jobs specified → running ALL jobs: {', '.join(args.jobs)}")

    for job_name in args.jobs:
        job_config = BACKUP_JOBS.get(job_name)
        if not job_config:
            logging.error(f"{job_name} - FAIL - Job not found in config.")
            send_alert(job_name, "Job not found in config.")
            print(f"[WARN] Job '{job_name}' not found in configuration. Skipping.")
            continue

        src = job_config.get("source")
        dest = job_config.get("destination")
        backup_job(job_name, src, dest)

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logging.critical(f"Program crashed: {e}")
        print(f"[CRITICAL] Program crashed: {e}")
        sys.exit(1)