# backupcfg.py

# Define backup jobs with source and destination paths
BACKUP_JOBS = {
    "job1": {
        "source": "/home/ec2-user/environment/topic1/documents",
        "destination": "/home/ec2-user/backups/documents"
    },
    "job2": {
        "source": "/home/ec2-user/environment/topic1/pictures",
        "destination": "/home/ec2-user/backups/pictures"
    },
    "job3": {
        "source": "/home/ec2-user/environment/topic1/videos",
        "destination": "/home/ec2-user/backups/videos"
    }
}


backupfilename = "backup.log"

