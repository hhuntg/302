# backupcfg.py
# Define backup jobs with source and destination paths

BACKUP_JOBS = {
    "job1": {  # Single file backup (success case)
        "source": "/home/ec2-user/environment/topic1/test_data/file1.txt",
        "destination": "/home/ec2-user/backups/files"
    },
    "job2": {  # Folder backup (success case)
        "source": "/home/ec2-user/environment/topic1/test_data/folder1",
        "destination": "/home/ec2-user/backups/folders"
    },
    "job3": {  # Non-existent path (failure case)
        "source": "/home/ec2-user/environment/topic1/test_data/nonexistent",
        "destination": "/home/ec2-user/backups/failure"
    }
}

